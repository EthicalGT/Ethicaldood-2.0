create table grocery(pid int primary key, pname varchar(20), quantity varchar(22), price varchar(22));
